from __future__ import annotations

import csv
import json
import math
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Iterable

import meshio
import numpy as np


@dataclass(frozen=True)
class RunRecord:
    case_name: str
    model_name: str
    base_dir: Path
    family: str
    files_by_timestep: dict[int, Path]


def append_progress_log(progress_path: Path, message: str) -> None:
    progress_path.parent.mkdir(parents=True, exist_ok=True)
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    with progress_path.open("a", encoding="utf-8") as handle:
        handle.write(f"[{timestamp}] {message}\n")


def extract_timestep(path: Path) -> int:
    stem = path.name.split(".")[0]
    try:
        return int(stem.split("-")[-1])
    except ValueError as exc:
        raise ValueError(f"Cannot extract timestep from {path}") from exc


def discover_family_files(base_dir: Path, family: str) -> dict[int, Path]:
    family_dir = base_dir / "output" / family
    if not family_dir.exists():
        return {}
    return {extract_timestep(path): path for path in sorted(family_dir.glob("*.0000.vtu"))}


def discover_dataset(dataset_root: Path, include_particles: bool, progress_path: Path) -> tuple[dict[str, RunRecord], list[RunRecord]]:
    source_root = dataset_root / "source"
    regenerated_root = dataset_root / "regenerated"
    source_records: dict[str, RunRecord] = {}
    regenerated_records: list[RunRecord] = []
    families = ["solution"]
    if include_particles:
        families.append("particles")

    for case_dir in sorted(source_root.iterdir()):
        if not case_dir.is_dir():
            continue
        case_name = case_dir.name
        solution_files = discover_family_files(case_dir, "solution")
        particle_files = discover_family_files(case_dir, "particles") if include_particles else {}
        if solution_files:
            source_records[case_name] = RunRecord(case_name, "source", case_dir, "solution", solution_files)
        elif particle_files:
            source_records[case_name] = RunRecord(case_name, "source", case_dir, "particles", particle_files)
        else:
            append_progress_log(progress_path, f"skip case {case_name}: no source VTU files available")

        if include_particles and particle_files:
            source_records[f"{case_name}::particles"] = RunRecord(case_name, "source", case_dir, "particles", particle_files)

    for case_dir in sorted(regenerated_root.iterdir()):
        if not case_dir.is_dir():
            continue
        for model_dir in sorted(case_dir.iterdir()):
            if not model_dir.is_dir():
                continue
            for family in families:
                files_by_timestep = discover_family_files(model_dir, family)
                if files_by_timestep:
                    regenerated_records.append(RunRecord(case_dir.name, model_dir.name, model_dir, family, files_by_timestep))

    return source_records, regenerated_records


def build_matches(reference: RunRecord, candidate: RunRecord, progress_path: Path) -> list[dict[str, object]]:
    if reference.family != candidate.family:
        append_progress_log(
            progress_path,
            f"skip family mismatch {reference.case_name} {candidate.model_name}: source={reference.family} candidate={candidate.family}",
        )
        return []

    candidate_steps = sorted(candidate.files_by_timestep)
    if not candidate_steps:
        append_progress_log(progress_path, f"skip {reference.case_name} {candidate.model_name} {candidate.family}: no candidate files")
        return []

    matches: list[dict[str, object]] = []
    for source_step, source_path in sorted(reference.files_by_timestep.items()):
        if source_step in candidate.files_by_timestep:
            matches.append(
                {
                    "source_timestep": source_step,
                    "matched_timestep": source_step,
                    "source_path": source_path,
                    "candidate_path": candidate.files_by_timestep[source_step],
                    "match_kind": "exact",
                }
            )
            continue

        insert_at = int(np.searchsorted(candidate_steps, source_step))
        if insert_at <= 0:
            matched_step = candidate_steps[0]
            match_kind = "clamped_first"
        elif insert_at >= len(candidate_steps):
            matched_step = candidate_steps[-1]
            match_kind = "clamped_last"
        else:
            lower_step = candidate_steps[insert_at - 1]
            upper_step = candidate_steps[insert_at]
            if abs(lower_step - source_step) <= abs(upper_step - source_step):
                matched_step = lower_step
                match_kind = "nearest_lower"
            else:
                matched_step = upper_step
                match_kind = "nearest_higher"

        append_progress_log(
            progress_path,
            f"timestep mismatch {reference.case_name} {candidate.model_name} {reference.family}: source={source_step:05d} matched={matched_step:05d} kind={match_kind}",
        )
        matches.append(
            {
                "source_timestep": source_step,
                "matched_timestep": matched_step,
                "source_path": source_path,
                "candidate_path": candidate.files_by_timestep[matched_step],
                "match_kind": match_kind,
            }
        )

    return matches


def read_mesh(path: Path) -> meshio.Mesh:
    return meshio.read(path)


def compute_bbox_difference(reference_mesh: meshio.Mesh, candidate_mesh: meshio.Mesh) -> float:
    ref_bounds = np.concatenate((reference_mesh.points.min(axis=0), reference_mesh.points.max(axis=0)))
    cand_bounds = np.concatenate((candidate_mesh.points.min(axis=0), candidate_mesh.points.max(axis=0)))
    return float(np.max(np.abs(ref_bounds - cand_bounds)))


def flatten_cells(mesh: meshio.Mesh) -> list[tuple[str, np.ndarray]]:
    flattened: list[tuple[str, np.ndarray]] = []
    for block in mesh.cells:
        flattened.append((block.type, np.asarray(block.data)))
    return flattened


def compute_topology_checks(reference_mesh: meshio.Mesh, candidate_mesh: meshio.Mesh) -> dict[str, object]:
    ref_cells = flatten_cells(reference_mesh)
    cand_cells = flatten_cells(candidate_mesh)
    num_points_match = reference_mesh.points.shape == candidate_mesh.points.shape
    num_cells_match = sum(block[1].shape[0] for block in ref_cells) == sum(block[1].shape[0] for block in cand_cells)
    connectivity_match = True
    if len(ref_cells) != len(cand_cells):
        connectivity_match = False
    else:
        for (ref_type, ref_data), (cand_type, cand_data) in zip(ref_cells, cand_cells):
            if ref_type != cand_type or ref_data.shape != cand_data.shape or not np.array_equal(ref_data, cand_data):
                connectivity_match = False
                break

    return {
        "num_points_match": bool(num_points_match),
        "num_cells_match": bool(num_cells_match),
        "bbox_difference": compute_bbox_difference(reference_mesh, candidate_mesh),
        "connectivity_match": bool(connectivity_match),
    }


def detect_common_fields(reference_mesh: meshio.Mesh, candidate_mesh: meshio.Mesh) -> list[tuple[str, str]]:
    common_fields: list[tuple[str, str]] = []

    for name in sorted(set(reference_mesh.point_data) & set(candidate_mesh.point_data)):
        ref_array = np.asarray(reference_mesh.point_data[name])
        cand_array = np.asarray(candidate_mesh.point_data[name])
        if ref_array.shape == cand_array.shape and ref_array.dtype.kind in "iuf" and cand_array.dtype.kind in "iuf":
            common_fields.append(("point", name))

    for name in sorted(set(reference_mesh.cell_data) & set(candidate_mesh.cell_data)):
        ref_blocks = reference_mesh.cell_data[name]
        cand_blocks = candidate_mesh.cell_data[name]
        if len(ref_blocks) != len(cand_blocks):
            continue
        compatible = True
        for ref_block, cand_block in zip(ref_blocks, cand_blocks):
            ref_array = np.asarray(ref_block)
            cand_array = np.asarray(cand_block)
            if ref_array.shape != cand_array.shape or ref_array.dtype.kind not in "iuf" or cand_array.dtype.kind not in "iuf":
                compatible = False
                break
        if compatible:
            common_fields.append(("cell", name))

    return common_fields


def get_field_array(mesh: meshio.Mesh, association: str, field_name: str) -> np.ndarray:
    if association == "point":
        return np.asarray(mesh.point_data[field_name], dtype=float)
    blocks = [np.asarray(block, dtype=float) for block in mesh.cell_data[field_name]]
    return np.concatenate(blocks, axis=0) if blocks else np.empty((0,), dtype=float)


def compute_field_metrics(reference_array: np.ndarray, candidate_array: np.ndarray) -> dict[str, float]:
    ref = np.asarray(reference_array, dtype=float)
    cand = np.asarray(candidate_array, dtype=float)
    diff = cand - ref
    l2 = float(np.linalg.norm(diff.ravel()))
    rmse = float(np.sqrt(np.mean(np.square(diff))))
    max_error = float(np.max(np.abs(diff)))
    ref_norm = float(np.linalg.norm(ref.ravel()))
    if ref_norm > 0.0:
        relative_error = float(l2 / ref_norm)
    elif l2 == 0.0:
        relative_error = 0.0
    else:
        relative_error = math.inf
    return {
        "l2": l2,
        "rmse": rmse,
        "max_error": max_error,
        "relative_error": relative_error,
    }


def export_diff_mesh(reference_mesh: meshio.Mesh, candidate_mesh: meshio.Mesh, fields: Iterable[tuple[str, str]], output_path: Path) -> bool:
    point_data = {name: np.asarray(values).copy() for name, values in reference_mesh.point_data.items()}
    cell_data = {name: [np.asarray(block).copy() for block in values] for name, values in reference_mesh.cell_data.items()}
    wrote_any = False

    for association, field_name in fields:
        if association == "point":
            point_data[f"diff__{field_name}"] = get_field_array(candidate_mesh, association, field_name) - get_field_array(
                reference_mesh, association, field_name
            )
        else:
            diff_blocks = []
            for ref_block, cand_block in zip(reference_mesh.cell_data[field_name], candidate_mesh.cell_data[field_name]):
                diff_blocks.append(np.asarray(cand_block, dtype=float) - np.asarray(ref_block, dtype=float))
            cell_data[f"diff__{field_name}"] = diff_blocks
        wrote_any = True

    if wrote_any:
        output_path.parent.mkdir(parents=True, exist_ok=True)
        diff_mesh = meshio.Mesh(
            points=np.asarray(reference_mesh.points).copy(),
            cells=reference_mesh.cells,
            point_data=point_data,
            cell_data=cell_data,
        )
        meshio.write(output_path, diff_mesh)

    return wrote_any


def metric_fieldnames() -> list[str]:
    return [
        "case_name",
        "model_name",
        "family",
        "source_timestep",
        "matched_timestep",
        "match_kind",
        "field_name",
        "l2",
        "rmse",
        "max_error",
        "relative_error",
        "num_points_match",
        "num_cells_match",
        "bbox_difference",
        "connectivity_match",
    ]


def write_csv_header(csv_path: Path) -> None:
    csv_path.parent.mkdir(parents=True, exist_ok=True)
    with csv_path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=metric_fieldnames())
        writer.writeheader()


def append_csv_row(csv_path: Path, row: dict[str, object]) -> None:
    with csv_path.open("a", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=metric_fieldnames())
        writer.writerow(row)


def write_csv_rows(csv_path: Path, fieldnames: list[str], rows: list[dict[str, object]]) -> None:
    csv_path.parent.mkdir(parents=True, exist_ok=True)
    with csv_path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


def start_json_rows(json_path: Path, metadata: dict[str, object]) -> None:
    json_path.parent.mkdir(parents=True, exist_ok=True)
    with json_path.open("w", encoding="utf-8") as handle:
        handle.write('{\n  "metadata": ')
        json.dump(metadata, handle, indent=2)
        handle.write(',\n  "rows": [\n')


def append_json_row(json_path: Path, row: dict[str, object], first_row: bool) -> None:
    with json_path.open("a", encoding="utf-8") as handle:
        if not first_row:
            handle.write(",\n")
        handle.write("    ")
        json.dump(row, handle, ensure_ascii=True)


def finish_json_rows(json_path: Path, summary: dict[str, object]) -> None:
    with json_path.open("a", encoding="utf-8") as handle:
        handle.write('\n  ],\n  "summary": ')
        json.dump(summary, handle, indent=2)
        handle.write("\n}\n")


def write_summary(summary_path: Path, lines: list[str]) -> None:
    summary_path.parent.mkdir(parents=True, exist_ok=True)
    with summary_path.open("w", encoding="utf-8") as handle:
        handle.write("\n".join(lines) + "\n")
