from __future__ import annotations

import argparse
import csv
import sys
from collections import defaultdict
from itertools import zip_longest
from pathlib import Path

import numpy as np

from vtu_compare_helpers import (
    RunRecord,
    append_csv_row,
    append_json_row,
    append_progress_log,
    build_matches,
    compute_field_metrics,
    compute_topology_checks,
    detect_common_fields,
    discover_dataset,
    export_diff_mesh,
    finish_json_rows,
    get_field_array,
    read_mesh,
    start_json_rows,
    write_csv_header,
    write_csv_rows,
    write_summary,
)


def parse_args() -> argparse.Namespace:
    workspace_root = Path(__file__).resolve().parents[1]
    default_dataset_root = workspace_root / "aspect_comparison_selected" / "aspect_comparison_selected" / "20260423_112326"
    default_output_dir = workspace_root / "analysis" / "vtu_compare"

    parser = argparse.ArgumentParser(description="Incremental VTU comparison for ASPECT source/regenerated outputs.")
    parser.add_argument("--dataset-root", type=Path, default=default_dataset_root)
    parser.add_argument("--output-dir", type=Path, default=default_output_dir)
    parser.add_argument("--progress-path", type=Path, default=workspace_root / "progress.txt")
    parser.add_argument("--include-particles", action="store_true", help="Also compare particle VTUs when available.")
    parser.add_argument("--case", action="append", default=[], help="Restrict to one or more case names.")
    parser.add_argument("--model", action="append", default=[], help="Restrict to one or more regenerated model names.")
    parser.add_argument("--max-matches", type=int, default=None, help="Stop after this many matched timestep pairs.")
    parser.add_argument("--export-diff", action="store_true", help="Export diff VTUs for compatible exact-mesh comparisons.")
    parser.add_argument(
        "--summarize-existing-output-dir",
        type=Path,
        default=None,
        help="Generate case_summary.txt from existing aggregate outputs without reprocessing VTUs.",
    )
    return parser.parse_args()


def normalize_filters(values: list[str]) -> set[str] | None:
    return set(values) if values else None


def candidate_sort_key(record: RunRecord) -> tuple[str, str, str]:
    return (record.case_name, record.model_name, record.family)


def init_metric_aggregate() -> dict[str, object]:
    return {
        "row_count": 0,
        "l2_sum": 0.0,
        "rmse_sum": 0.0,
        "relative_error_sum": 0.0,
        "max_error_observed": 0.0,
    }


def update_metric_aggregate(aggregate: dict[str, object], row: dict[str, object]) -> None:
    aggregate["row_count"] += 1
    aggregate["l2_sum"] += float(row["l2"])
    aggregate["rmse_sum"] += float(row["rmse"])
    aggregate["relative_error_sum"] += float(row["relative_error"])
    aggregate["max_error_observed"] = max(float(aggregate["max_error_observed"]), float(row["max_error"]))


def finalize_metric_aggregate(aggregate: dict[str, object]) -> tuple[float, float, float, float]:
    row_count = int(aggregate["row_count"])
    if row_count <= 0:
        return 0.0, 0.0, 0.0, 0.0
    return (
        float(aggregate["l2_sum"]) / row_count,
        float(aggregate["rmse_sum"]) / row_count,
        float(aggregate["relative_error_sum"]) / row_count,
        float(aggregate["max_error_observed"]),
    )


def topology_success(topology: dict[str, object]) -> bool:
    return bool(
        topology["num_points_match"]
        and topology["num_cells_match"]
        and topology["connectivity_match"]
        and float(topology["bbox_difference"]) == 0.0
    )


def load_csv_rows(csv_path: Path) -> list[dict[str, str]]:
    with csv_path.open("r", newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


def parse_dataset_root_from_summary(summary_path: Path) -> Path | None:
    if not summary_path.exists():
        return None
    for line in summary_path.read_text(encoding="utf-8").splitlines():
        if line.startswith("dataset_root: "):
            return Path(line.split(": ", 1)[1].strip())
    return None


def choose_parameter_file(run_dir: Path) -> Path | None:
    for candidate in (
        run_dir / "output" / "parameters.prm",
        run_dir / "output" / "original.prm",
        run_dir / "input.prm",
    ):
        if candidate.exists():
            return candidate
    return None


def normalize_prm_lines(path: Path) -> list[str]:
    lines: list[str] = []
    for raw_line in path.read_text(encoding="utf-8", errors="ignore").splitlines():
        stripped = raw_line.strip()
        if not stripped or stripped.startswith("#"):
            continue
        if "#" in stripped:
            stripped = stripped.split("#", 1)[0].strip()
        normalized = " ".join(stripped.split())
        if normalized:
            lines.append(normalized)
    return lines


def compare_parameter_files(source_path: Path | None, candidate_path: Path | None) -> tuple[float, int]:
    if source_path is None or candidate_path is None:
        return 0.0, 0
    source_lines = normalize_prm_lines(source_path)
    candidate_lines = normalize_prm_lines(candidate_path)
    max_len = max(len(source_lines), len(candidate_lines))
    if max_len == 0:
        return 1.0, 0
    matching = 0
    differing = 0
    for source_line, candidate_line in zip_longest(source_lines, candidate_lines, fillvalue=None):
        if source_line == candidate_line:
            matching += 1
        else:
            differing += 1
    return matching / max_len, differing


def parse_numeric_text_table(path: Path) -> np.ndarray | None:
    rows: list[list[float]] = []
    for raw_line in path.read_text(encoding="utf-8", errors="ignore").splitlines():
        stripped = raw_line.strip()
        if not stripped or stripped.startswith("#"):
            continue
        numeric_tokens: list[float] = []
        for token in stripped.split():
            try:
                numeric_tokens.append(float(token))
            except ValueError:
                continue
        if numeric_tokens:
            rows.append(numeric_tokens)
    if not rows:
        return None
    width = len(rows[0])
    if any(len(row) != width for row in rows):
        return None
    return np.asarray(rows, dtype=float)


def compare_numeric_tables(source_path: Path | None, candidate_path: Path | None) -> tuple[bool, float | None, dict[str, float] | None, int]:
    if source_path is None or candidate_path is None or not source_path.exists() or not candidate_path.exists():
        return False, None, None, 0
    source_array = parse_numeric_text_table(source_path)
    candidate_array = parse_numeric_text_table(candidate_path)
    if source_array is None or candidate_array is None:
        return False, None, None, 0
    if source_array.shape != candidate_array.shape:
        return False, None, None, int(source_array.shape[1]) if source_array.ndim == 2 else 0
    similarity = float(np.mean(np.isclose(source_array, candidate_array, rtol=1e-9, atol=1e-12)))
    metrics = compute_field_metrics(source_array, candidate_array)
    compared_fields = int(source_array.shape[1]) if source_array.ndim == 2 else 1
    return True, similarity, metrics, compared_fields


def compute_fallback_rows(dataset_root: Path) -> list[dict[str, object]]:
    rows: list[dict[str, object]] = []
    source_root = dataset_root / "source"
    regenerated_root = dataset_root / "regenerated"
    for case_dir in sorted(source_root.iterdir()):
        if not case_dir.is_dir():
            continue
        case_name = case_dir.name
        solution_vtus = list((case_dir / "output" / "solution").glob("*.0000.vtu")) if (case_dir / "output" / "solution").exists() else []
        if solution_vtus:
            continue

        source_param = choose_parameter_file(case_dir)
        source_gnuplot = case_dir / "output" / "solution" / "solution-00000.0000.gnuplot"
        source_stats = case_dir / "output" / "statistics"
        case_regenerated_root = regenerated_root / case_name
        if not case_regenerated_root.exists():
            continue

        for model_dir in sorted(case_regenerated_root.iterdir()):
            if not model_dir.is_dir():
                continue
            candidate_param = choose_parameter_file(model_dir)
            param_similarity, differing_parameter_count = compare_parameter_files(source_param, candidate_param)

            gnuplot_path = model_dir / "output" / "solution" / "solution-00000.0000.gnuplot"
            gnuplot_match, gnuplot_similarity, gnuplot_metrics, compared_fields = compare_numeric_tables(source_gnuplot, gnuplot_path)

            stats_path = model_dir / "output" / "statistics"
            stats_match, stats_similarity, _, _ = compare_numeric_tables(source_stats, stats_path)

            similarity_components = [param_similarity]
            if gnuplot_similarity is not None:
                similarity_components.append(gnuplot_similarity)
            if stats_similarity is not None:
                similarity_components.append(stats_similarity)
            similarity_score = float(sum(similarity_components) / len(similarity_components)) if similarity_components else 0.0
            structural_match = bool(
                source_param is not None
                and candidate_param is not None
                and gnuplot_match
                and stats_match
            )
            comparison_type_parts = ["fallback_parameters.prm"]
            if gnuplot_match:
                comparison_type_parts.append("solution.gnuplot")
            if stats_match:
                comparison_type_parts.append("statistics")

            rows.append(
                {
                    "case_name": case_name,
                    "model_name": model_dir.name,
                    "compared_timesteps": 1 if gnuplot_match or stats_match else 0,
                    "compared_fields": compared_fields,
                    "mean_l2": gnuplot_metrics["l2"] if gnuplot_metrics else "",
                    "mean_rmse": gnuplot_metrics["rmse"] if gnuplot_metrics else "",
                    "mean_relative_error": gnuplot_metrics["relative_error"] if gnuplot_metrics else "",
                    "max_error_observed": gnuplot_metrics["max_error"] if gnuplot_metrics else "",
                    "topology_match_fraction": "",
                    "comparison_type": "+".join(comparison_type_parts),
                    "similarity_score": similarity_score,
                    "differing_parameter_count": differing_parameter_count,
                    "structural_match": structural_match,
                }
            )
    return rows


def ensure_fallback_per_case_summary(output_dir: Path) -> list[dict[str, object]]:
    per_case_path = output_dir / "per_case_summary.csv"
    existing_rows = load_csv_rows(per_case_path) if per_case_path.exists() else []
    if existing_rows:
        existing_rows = [dict(row) for row in existing_rows]
    dataset_root = parse_dataset_root_from_summary(output_dir / "summary.txt")
    fallback_rows = compute_fallback_rows(dataset_root) if dataset_root else []

    has_new_schema = bool(existing_rows and "comparison_type" in existing_rows[0])
    normalized_rows: list[dict[str, object]] = []
    for row in existing_rows:
        normalized_rows.append(
            {
                "case_name": row["case_name"],
                "model_name": row["model_name"],
                "compared_timesteps": row.get("compared_timesteps", ""),
                "compared_fields": row.get("compared_fields", ""),
                "mean_l2": row.get("mean_l2", ""),
                "mean_rmse": row.get("mean_rmse", ""),
                "mean_relative_error": row.get("mean_relative_error", ""),
                "max_error_observed": row.get("max_error_observed", ""),
                "topology_match_fraction": row.get("topology_match_fraction", ""),
                "comparison_type": row.get("comparison_type", "solution_vtu"),
                "similarity_score": row.get("similarity_score", ""),
                "differing_parameter_count": row.get("differing_parameter_count", ""),
                "structural_match": row.get(
                    "structural_match",
                    "True" if row.get("topology_match_fraction", "") not in ("", None) and float(row["topology_match_fraction"]) == 1.0 else "",
                ),
            }
        )

    row_keys = {(row["case_name"], row["model_name"]) for row in normalized_rows}
    for fallback_row in fallback_rows:
        key = (str(fallback_row["case_name"]), str(fallback_row["model_name"]))
        if key not in row_keys:
            normalized_rows.append(fallback_row)

    normalized_rows.sort(key=lambda row: (str(row["case_name"]), str(row["model_name"])))
    write_csv_rows(
        per_case_path,
        [
            "case_name",
            "model_name",
            "compared_timesteps",
            "compared_fields",
            "mean_l2",
            "mean_rmse",
            "mean_relative_error",
            "max_error_observed",
            "topology_match_fraction",
            "comparison_type",
            "similarity_score",
            "differing_parameter_count",
            "structural_match",
        ],
        normalized_rows,
    )
    return normalized_rows


def build_case_summary_text(output_dir: Path) -> str:
    per_case_rows = ensure_fallback_per_case_summary(output_dir)
    per_field_rows = load_csv_rows(output_dir / "per_field_summary.csv")
    dataset_root = parse_dataset_root_from_summary(output_dir / "summary.txt")

    all_cases: list[str]
    if dataset_root and (dataset_root / "source").exists():
        all_cases = sorted(path.name for path in (dataset_root / "source").iterdir() if path.is_dir())
    else:
        all_cases = sorted({row["case_name"] for row in per_case_rows})

    lines = [
        "==================================================",
        "CASE SUMMARY",
        "============",
        "",
    ]

    for idx, case_name in enumerate(all_cases):
        case_rows = [row for row in per_case_rows if row["case_name"] == case_name]
        case_field_rows = [row for row in per_field_rows if row["case_name"] == case_name]

        lines.append(f"Case: {case_name}")
        if not case_rows:
            lines.append("Compared models: 0")
            lines.append("Compared timesteps: 0")
            lines.append("Topology mismatches: 0")
            lines.append("")
            lines.append("Observations:")
            lines.append("")
            lines.append("* no VTU comparisons were available for this case")
            lines.append("* the case was skipped automatically")
            lines.append("")
            if idx != len(all_cases) - 1:
                lines.append("---")
                lines.append("")
            continue

        fallback_rows = [row for row in case_rows if str(row.get("comparison_type", "")).startswith("fallback_")]
        if fallback_rows and len(fallback_rows) == len(case_rows):
            compared_models = len(case_rows)
            total_compared_timesteps = sum(int(row["compared_timesteps"]) for row in case_rows)
            structural_mismatches = sum(0 if str(row["structural_match"]).lower() == "true" else 1 for row in case_rows)
            best_similarity = max(float(row["similarity_score"]) for row in case_rows)
            best_rows = [row for row in case_rows if abs(float(row["similarity_score"]) - best_similarity) <= 1e-15]
            worst_row = min(case_rows, key=lambda row: float(row["similarity_score"]))

            lines.append(f"Compared models: {compared_models}")
            lines.append(f"Compared timesteps: {total_compared_timesteps}")
            lines.append(f"Topology mismatches: {structural_mismatches}")
            lines.append("")
            lines.append("Fallback comparison: completed")
            lines.append("")
            lines.append(f"Best models (tie, similarity={best_similarity:.6g}):")
            lines.append("")
            for row in sorted(best_rows, key=lambda item: item["model_name"]):
                lines.append(f"* {row['model_name']}")

            if float(worst_row["similarity_score"]) < best_similarity:
                lines.append("")
                lines.append("Outlier:")
                lines.append("")
                lines.append(f"* {worst_row['model_name']}")
                lines.append(f"  artifact type: {worst_row['comparison_type']}")
                lines.append(f"  similarity_score: {float(worst_row['similarity_score']):.6g}")
                lines.append(f"  differing_parameter_count: {worst_row['differing_parameter_count']}")
                if str(worst_row["mean_rmse"]) not in ("", None):
                    lines.append(f"  mean_rmse: {float(worst_row['mean_rmse']):.6g}")

            lines.append("")
            lines.append("Observations:")
            lines.append("")
            lines.append("* fallback comparison completed using existing non-VTU artifacts")
            if structural_mismatches == 0:
                lines.append("* regenerated outputs structurally match source outputs for all compared runs")
            else:
                lines.append(f"* structural mismatches were observed in {structural_mismatches} regenerated runs")
            if len(best_rows) >= max(1, compared_models - 1):
                lines.append("* most fallback comparisons were numerically identical")

            lines.append("")
            if idx != len(all_cases) - 1:
                lines.append("---")
                lines.append("")
            continue

        compared_models = len(case_rows)
        total_compared_timesteps = sum(int(row["compared_timesteps"]) for row in case_rows)
        topology_mismatches = sum(
            int(round(int(row["compared_timesteps"]) * (1.0 - float(row["topology_match_fraction"])))) for row in case_rows
        )
        best_rmse = min(float(row["mean_rmse"]) for row in case_rows)
        best_rows = [row for row in case_rows if abs(float(row["mean_rmse"]) - best_rmse) <= 1e-15]
        worst_row = max(case_rows, key=lambda row: float(row["mean_rmse"]))

        lines.append(f"Compared models: {compared_models}")
        lines.append(f"Compared timesteps: {total_compared_timesteps}")
        lines.append(f"Topology mismatches: {topology_mismatches}")
        lines.append("")
        lines.append(f"Best models (tie, RMSE={best_rmse:.6g}):")
        lines.append("")
        for row in sorted(best_rows, key=lambda item: item["model_name"]):
            lines.append(f"* {row['model_name']}")

        if float(worst_row["mean_rmse"]) > best_rmse:
            outlier_fields = [
                row
                for row in case_field_rows
                if row["model_name"] == worst_row["model_name"]
            ]
            dominant_field = max(outlier_fields, key=lambda row: float(row["mean_rmse"])) if outlier_fields else None
            lines.append("")
            lines.append("Outlier:")
            lines.append("")
            lines.append(f"* {worst_row['model_name']}")
            if dominant_field:
                lines.append(f"  dominant failing field: {dominant_field['field_name']}")
                lines.append(f"  mean_rmse: {float(dominant_field['mean_rmse']):.6g}")
                lines.append(f"  max_error: {float(dominant_field['max_error_observed']):.6g}")

        lines.append("")
        lines.append("Observations:")
        lines.append("")
        if topology_mismatches == 0:
            lines.append("* all runs preserved topology")
        else:
            lines.append(f"* topology mismatches were observed in {topology_mismatches} matched timesteps")

        zero_rows = sum(1 for row in case_rows if abs(float(row["mean_rmse"])) <= 1e-15)
        if zero_rows >= max(1, compared_models - 1):
            lines.append("* most runs were numerically identical")

        if dataset_root and case_name == "convection-box-particles__convection-box-particles":
            outlier_dir = dataset_root / "regenerated" / case_name / "anthropic__claude-3-haiku" / "output" / "solution"
            if outlier_dir.exists():
                outlier_file_count = len(list(outlier_dir.glob("*.0000.vtu")))
                matched = next((row for row in case_rows if row["model_name"] == "anthropic__claude-3-haiku"), None)
                if matched and outlier_file_count > int(matched["compared_timesteps"]):
                    lines.append("* extra regenerated timesteps from anthropic__claude-3-haiku were ignored correctly")

        lines.append("")
        if idx != len(all_cases) - 1:
            lines.append("---")
            lines.append("")

    lines.append("==================================================")
    return "\n".join(lines) + "\n"


def build_overall_summary_text(output_dir: Path, processed_matches: int | None = None, skipped_runs: int | None = None, topology_mismatches: int | None = None) -> str:
    per_case_rows = ensure_fallback_per_case_summary(output_dir)
    model_ranking_rows = load_csv_rows(output_dir / "model_ranking.csv") if (output_dir / "model_ranking.csv").exists() else []
    case_rank_data: dict[str, list[dict[str, object]]] = defaultdict(list)
    for row in per_case_rows:
        case_rank_data[str(row["case_name"])].append(row)

    lines = ["Overall Comparison Summary"]
    for case_name in sorted(case_rank_data):
        case_rows = case_rank_data[case_name]
        fallback_rows = [row for row in case_rows if str(row.get("comparison_type", "")).startswith("fallback_")]
        if fallback_rows and len(fallback_rows) == len(case_rows):
            ranked = sorted(case_rows, key=lambda row: (-float(row["similarity_score"]), float(row["differing_parameter_count"])))
            best = ranked[0]
            worst = ranked[-1]
            lines.append(
                f"{best['model_name']} achieved highest fallback similarity on {case_name} ({float(best['similarity_score']):.6g})."
            )
            lines.append(
                f"{worst['model_name']} had lowest fallback similarity on {case_name} ({float(worst['similarity_score']):.6g})."
            )
        else:
            ranked = sorted(case_rows, key=lambda row: (float(row["mean_rmse"]), float(row["mean_relative_error"])))
            best = ranked[0]
            worst = ranked[-1]
            lines.append(
                f"{best['model_name']} achieved lowest average RMSE on {case_name} ({float(best['mean_rmse']):.6g})."
            )
            lines.append(
                f"{worst['model_name']} had highest average RMSE on {case_name} ({float(worst['mean_rmse']):.6g})."
            )

    if model_ranking_rows:
        best_global = min(model_ranking_rows, key=lambda row: (float(row["global_mean_rmse"]), float(row["global_mean_relative_error"])))
        worst_global = max(model_ranking_rows, key=lambda row: (float(row["global_mean_rmse"]), float(row["global_mean_relative_error"])))
        lines.append(f"Lowest overall average RMSE: {best_global['model_name']} ({float(best_global['global_mean_rmse']):.6g}).")
        lines.append(f"Highest overall average RMSE: {worst_global['model_name']} ({float(worst_global['global_mean_rmse']):.6g}).")

    if topology_mismatches is None:
        topology_mismatches = 0
        for row in per_case_rows:
            topo = row.get("topology_match_fraction", "")
            if str(topo) not in ("", "None"):
                compared = int(row["compared_timesteps"])
                topology_mismatches += int(round(compared * (1.0 - float(topo))))
            elif str(row.get("structural_match", "")).lower() == "false":
                topology_mismatches += 1
    if skipped_runs is None:
        skipped_runs = 0
    if processed_matches is None:
        processed_matches = sum(int(row["compared_timesteps"]) for row in per_case_rows if str(row["compared_timesteps"]).strip())

    lines.append(f"Topology mismatches observed: {topology_mismatches}")
    lines.append(f"Skipped runs: {skipped_runs}")
    lines.append(f"Total comparisons completed: {processed_matches}")
    return "\n".join(lines) + "\n"


def compare_match(
    case_name: str,
    model_name: str,
    family: str,
    match: dict[str, object],
    output_dir: Path,
    progress_path: Path,
    export_diff: bool,
) -> tuple[list[dict[str, object]], dict[str, int]]:
    source_path = Path(match["source_path"])
    candidate_path = Path(match["candidate_path"])
    source_timestep = int(match["source_timestep"])
    matched_timestep = int(match["matched_timestep"])
    match_kind = str(match["match_kind"])

    reference_mesh = read_mesh(source_path)
    candidate_mesh = read_mesh(candidate_path)
    topology = compute_topology_checks(reference_mesh, candidate_mesh)
    common_fields = detect_common_fields(reference_mesh, candidate_mesh)
    stats = {"rows": 0, "skipped_fields": 0, "warning_count": 0}

    if not common_fields:
        append_progress_log(
            progress_path,
            f"skip fields {case_name} {model_name} {family} timestep={source_timestep:05d}: no compatible common numeric fields",
        )
        stats["warning_count"] += 1
        return [], stats

    rows: list[dict[str, object]] = []
    diff_fields: list[tuple[str, str]] = []
    for association, field_name in common_fields:
        ref_array = get_field_array(reference_mesh, association, field_name)
        cand_array = get_field_array(candidate_mesh, association, field_name)
        if ref_array.shape != cand_array.shape:
            append_progress_log(
                progress_path,
                f"skip field shape mismatch {case_name} {model_name} {family} timestep={source_timestep:05d} field={association}:{field_name}",
            )
            stats["skipped_fields"] += 1
            stats["warning_count"] += 1
            continue

        metrics = compute_field_metrics(ref_array, cand_array)
        row = {
            "case_name": case_name,
            "model_name": model_name,
            "family": family,
            "source_timestep": source_timestep,
            "matched_timestep": matched_timestep,
            "match_kind": match_kind,
            "field_name": f"{association}:{field_name}",
            "l2": metrics["l2"],
            "rmse": metrics["rmse"],
            "max_error": metrics["max_error"],
            "relative_error": metrics["relative_error"],
            "num_points_match": topology["num_points_match"],
            "num_cells_match": topology["num_cells_match"],
            "bbox_difference": topology["bbox_difference"],
            "connectivity_match": topology["connectivity_match"],
        }
        rows.append(row)
        diff_fields.append((association, field_name))
        stats["rows"] += 1

    if export_diff and rows and topology["num_points_match"] and topology["num_cells_match"]:
        diff_path = (
            output_dir
            / "diff_vtu"
            / case_name
            / model_name
            / family
            / f"diff-source-{source_timestep:05d}-matched-{matched_timestep:05d}.vtu"
        )
        if export_diff_mesh(reference_mesh, candidate_mesh, diff_fields, diff_path):
            append_progress_log(
                progress_path,
                f"exported diff VTU {case_name} {model_name} {family} source={source_timestep:05d} matched={matched_timestep:05d}",
            )

    return rows, stats


def main() -> int:
    args = parse_args()
    if args.summarize_existing_output_dir is not None:
        output_dir = args.summarize_existing_output_dir.resolve()
        progress_path = args.progress_path.resolve()
        text = build_case_summary_text(output_dir)
        overall_text = build_overall_summary_text(output_dir)
        case_summary_path = output_dir / "case_summary.txt"
        overall_summary_path = output_dir / "overall_summary.txt"
        write_summary(case_summary_path, text.rstrip().splitlines())
        write_summary(overall_summary_path, overall_text.rstrip().splitlines())
        append_progress_log(progress_path, f"generated case_summary.txt from existing aggregate outputs at {output_dir}")
        sys.stdout.write(text)
        return 0

    dataset_root = args.dataset_root.resolve()
    output_dir = args.output_dir.resolve()
    progress_path = args.progress_path.resolve()
    case_filter = normalize_filters(args.case)
    model_filter = normalize_filters(args.model)

    append_progress_log(progress_path, f"starting VTU comparison run dataset_root={dataset_root}")
    source_records, regenerated_records = discover_dataset(dataset_root, args.include_particles, progress_path)

    csv_path = output_dir / "metrics.csv"
    json_path = output_dir / "metrics.json"
    summary_path = output_dir / "summary.txt"
    per_case_summary_path = output_dir / "per_case_summary.csv"
    per_field_summary_path = output_dir / "per_field_summary.csv"
    model_ranking_path = output_dir / "model_ranking.csv"
    overall_summary_path = output_dir / "overall_summary.txt"
    case_summary_path = output_dir / "case_summary.txt"
    write_csv_header(csv_path)
    metadata = {
        "dataset_root": str(dataset_root),
        "include_particles": bool(args.include_particles),
        "case_filter": sorted(case_filter) if case_filter else [],
        "model_filter": sorted(model_filter) if model_filter else [],
        "max_matches": args.max_matches,
    }
    start_json_rows(json_path, metadata)

    first_json_row = True
    processed_matches = 0
    written_rows = 0
    skipped_runs = 0
    skipped_fields = 0
    warnings = 0
    compared_families: set[str] = set()
    case_model_stats: dict[tuple[str, str], dict[str, object]] = {}
    field_stats: dict[tuple[str, str, str], dict[str, object]] = {}
    model_stats: dict[str, dict[str, object]] = {}
    topology_timestep_seen: set[tuple[str, str, str, int, int]] = set()
    skipped_run_messages: list[str] = []

    for candidate in sorted(regenerated_records, key=candidate_sort_key):
        if case_filter and candidate.case_name not in case_filter:
            continue
        if model_filter and candidate.model_name not in model_filter:
            continue
        if candidate.case_name == "muparser_temperature_example__muparser-temperature-example":
            message = f"skip case {candidate.case_name} {candidate.model_name}: no VTU targets in dataset"
            append_progress_log(progress_path, message)
            skipped_run_messages.append(message)
            skipped_runs += 1
            warnings += 1
            continue

        source_key = candidate.case_name if candidate.family == "solution" else f"{candidate.case_name}::particles"
        reference = source_records.get(source_key)
        if reference is None:
            message = f"skip run {candidate.case_name} {candidate.model_name} {candidate.family}: no source counterpart"
            append_progress_log(progress_path, message)
            skipped_run_messages.append(message)
            skipped_runs += 1
            warnings += 1
            continue

        matches = build_matches(reference, candidate, progress_path)
        if not matches:
            skipped_run_messages.append(f"skip run {candidate.case_name} {candidate.model_name} {candidate.family}: no timestep matches")
            skipped_runs += 1
            warnings += 1
            continue

        compared_families.add(candidate.family)
        for match in matches:
            rows, stats = compare_match(
                candidate.case_name,
                candidate.model_name,
                candidate.family,
                match,
                output_dir,
                progress_path,
                args.export_diff,
            )
            processed_matches += 1
            skipped_fields += stats["skipped_fields"]
            warnings += stats["warning_count"]
            topology_key = (candidate.case_name, candidate.model_name)
            case_entry = case_model_stats.setdefault(
                topology_key,
                {
                    "metrics": init_metric_aggregate(),
                    "fields": set(),
                    "timesteps": set(),
                    "topology_total": 0,
                    "topology_matches": 0,
                },
            )

            if rows:
                timestep_key = (
                    candidate.case_name,
                    candidate.model_name,
                    candidate.family,
                    int(match["source_timestep"]),
                    int(match["matched_timestep"]),
                )
                if timestep_key not in topology_timestep_seen:
                    topology_timestep_seen.add(timestep_key)
                    case_entry["topology_total"] += 1
                    if topology_success(rows[0]):
                        case_entry["topology_matches"] += 1

            for row in rows:
                append_csv_row(csv_path, row)
                append_json_row(json_path, row, first_json_row)
                first_json_row = False
                written_rows += 1
                update_metric_aggregate(case_entry["metrics"], row)
                case_entry["fields"].add(str(row["field_name"]))
                case_entry["timesteps"].add(int(row["source_timestep"]))

                field_key = (str(row["case_name"]), str(row["model_name"]), str(row["field_name"]))
                field_entry = field_stats.setdefault(
                    field_key,
                    {
                        "metrics": init_metric_aggregate(),
                        "timesteps": set(),
                    },
                )
                update_metric_aggregate(field_entry["metrics"], row)
                field_entry["timesteps"].add(int(row["source_timestep"]))

                model_entry = model_stats.setdefault(
                    str(row["model_name"]),
                    {
                        "metrics": init_metric_aggregate(),
                        "cases": set(),
                    },
                )
                update_metric_aggregate(model_entry["metrics"], row)
                model_entry["cases"].add(str(row["case_name"]))

            if args.max_matches is not None and processed_matches >= args.max_matches:
                append_progress_log(progress_path, f"stopping early after max-matches={args.max_matches}")
                break

        if args.max_matches is not None and processed_matches >= args.max_matches:
            break

    summary = {
        "processed_matches": processed_matches,
        "written_rows": written_rows,
        "skipped_runs": skipped_runs,
        "skipped_fields": skipped_fields,
        "warnings": warnings,
        "families": sorted(compared_families),
    }
    finish_json_rows(json_path, summary)

    per_case_rows: list[dict[str, object]] = []
    case_rank_data: dict[str, list[dict[str, object]]] = defaultdict(list)
    topology_mismatch_rows = 0
    for (case_name, model_name), entry in sorted(case_model_stats.items()):
        mean_l2, mean_rmse, mean_relative_error, max_error_observed = finalize_metric_aggregate(entry["metrics"])
        topology_total = int(entry["topology_total"])
        topology_matches = int(entry["topology_matches"])
        topology_fraction = float(topology_matches / topology_total) if topology_total else 0.0
        if topology_matches != topology_total:
            topology_mismatch_rows += topology_total - topology_matches
        row = {
            "case_name": case_name,
            "model_name": model_name,
            "compared_timesteps": len(entry["timesteps"]),
            "compared_fields": len(entry["fields"]),
            "mean_l2": mean_l2,
            "mean_rmse": mean_rmse,
            "mean_relative_error": mean_relative_error,
            "max_error_observed": max_error_observed,
            "topology_match_fraction": topology_fraction,
            "comparison_type": "solution_vtu",
            "similarity_score": "",
            "differing_parameter_count": "",
            "structural_match": topology_fraction == 1.0,
        }
        per_case_rows.append(row)
        case_rank_data[case_name].append(row)

    per_field_rows: list[dict[str, object]] = []
    for (case_name, model_name, field_name), entry in sorted(field_stats.items()):
        mean_l2, mean_rmse, mean_relative_error, max_error_observed = finalize_metric_aggregate(entry["metrics"])
        per_field_rows.append(
            {
                "case_name": case_name,
                "model_name": model_name,
                "field_name": field_name,
                "compared_timesteps": len(entry["timesteps"]),
                "mean_l2": mean_l2,
                "mean_rmse": mean_rmse,
                "mean_relative_error": mean_relative_error,
                "max_error_observed": max_error_observed,
            }
        )

    model_ranking_rows: list[dict[str, object]] = []
    for model_name, entry in sorted(model_stats.items()):
        _, mean_rmse, mean_relative_error, max_error_observed = finalize_metric_aggregate(entry["metrics"])
        model_ranking_rows.append(
            {
                "model_name": model_name,
                "compared_cases": len(entry["cases"]),
                "global_mean_rmse": mean_rmse,
                "global_mean_relative_error": mean_relative_error,
                "global_max_error": max_error_observed,
            }
        )

    write_csv_rows(
        per_case_summary_path,
        [
            "case_name",
            "model_name",
            "compared_timesteps",
            "compared_fields",
            "mean_l2",
            "mean_rmse",
            "mean_relative_error",
            "max_error_observed",
            "topology_match_fraction",
            "comparison_type",
            "similarity_score",
            "differing_parameter_count",
            "structural_match",
        ],
        per_case_rows,
    )
    per_case_rows = ensure_fallback_per_case_summary(output_dir)
    case_rank_data = defaultdict(list)
    for row in per_case_rows:
        case_rank_data[str(row["case_name"])].append(row)
    write_csv_rows(
        per_field_summary_path,
        [
            "case_name",
            "model_name",
            "field_name",
            "compared_timesteps",
            "mean_l2",
            "mean_rmse",
            "mean_relative_error",
            "max_error_observed",
        ],
        per_field_rows,
    )
    write_csv_rows(
        model_ranking_path,
        [
            "model_name",
            "compared_cases",
            "global_mean_rmse",
            "global_mean_relative_error",
            "global_max_error",
        ],
        model_ranking_rows,
    )

    summary_lines = [
        "VTU Comparison Summary",
        f"dataset_root: {dataset_root}",
        f"output_dir: {output_dir}",
        f"processed_matches: {processed_matches}",
        f"written_rows: {written_rows}",
        f"skipped_runs: {skipped_runs}",
        f"skipped_fields: {skipped_fields}",
        f"warnings: {warnings}",
        f"families_compared: {', '.join(sorted(compared_families)) if compared_families else 'none'}",
        f"include_particles: {args.include_particles}",
        f"case_filter: {', '.join(sorted(case_filter)) if case_filter else 'all'}",
        f"model_filter: {', '.join(sorted(model_filter)) if model_filter else 'all'}",
    ]
    write_summary(summary_path, summary_lines)
    overall_text = build_overall_summary_text(output_dir, processed_matches=processed_matches, skipped_runs=skipped_runs, topology_mismatches=topology_mismatch_rows)
    if skipped_run_messages:
        overall_text = overall_text.rstrip() + "\nSkipped run details:\n" + "\n".join(skipped_run_messages) + "\n"
    write_summary(overall_summary_path, overall_text.rstrip().splitlines())
    case_summary_text = build_case_summary_text(output_dir)
    write_summary(case_summary_path, case_summary_text.rstrip().splitlines())
    sys.stdout.write(case_summary_text)
    append_progress_log(progress_path, f"completed VTU comparison run processed_matches={processed_matches} written_rows={written_rows}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
